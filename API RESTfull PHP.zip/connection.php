<?php
    // estabelecendo conexão com o banco de dados MySQL
    $conn = mysqli_connect("localhost", "root", "", "tabela-produtos");