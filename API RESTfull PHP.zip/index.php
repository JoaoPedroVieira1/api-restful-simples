<?php
require 'connection.php'; // arquivo de conexão com o banco de dados
require 'productControllers.php';

$method = $_SERVER['REQUEST_METHOD'];
$controller = new ProductController($conn);
// Função para criar um novo registro
/*function createProduct($data) {
    global $conn;

    $product_code = mysqli_real_escape_string($conn, $data->ProductCode);
    $product_name = mysqli_real_escape_string($conn, $data->ProductName);
    $price = floatval($data->Price);
    $price_promotion = floatval($data->PricePromotion);
    $tax = floatval($data->Tax);
    $promotion = intval($data->Promotion);
    $is_active = intval($data->IsActive);
    $created = date("Y-m-d");

    $query = "INSERT INTO product(ProductCode, ProductName, Price, PricePromotion, Tax, Promotion, IsActive, CreatedAt) 
              VALUES ('$product_code', '$product_name', '$price', '$price_promotion', '$tax', '$promotion', '$is_active', '$created')";

    $result = mysqli_query($conn, $query);

    if ($result) {
        $output = [
            "status" => 200,
            "data" => "Data insert successfully",
            "error" => false
        ];
    } else {
        $output = [
            "status" => 500,
            "data" => "Failed to insert data",
            "error" => true
        ];
    }

    echo json_encode($output);
}

// Função para obter um registro específico
function getProduct($id) {
    global $conn;

    $id = mysqli_real_escape_string($conn, $id);

    $query = "SELECT * FROM product WHERE ID='$id' AND IsActive='Active'";
    $result = mysqli_query($conn, $query);
    $numRows = mysqli_num_rows($result);

    if ($numRows > 0) {
        $output = mysqli_fetch_assoc($result);
        $output = [
            "status" => 200,
            "data" => $output,
            "error" => false
        ];
    } else {
        $output = [
            "status" => 404,
            "data" => "No Record Found",
            "error" => true
        ];
    }

    echo json_encode($output);
}

// Função para obter todos os registros
function getAllProducts() {
    global $conn;

    $query = "SELECT * FROM product";
    $result = mysqli_query($conn, $query);
    $output = array();

    while ($row = mysqli_fetch_assoc($result)) {
        array_push($output, $row);
    }

    $output = [
        "status" => 200,
        "data" => $output,
        "error" => false
    ];

    echo json_encode($output);
}

// Função para atualizar um registro existente
function updateProduct($id, $data) {
    global $conn;

    $id = mysqli_real_escape_string($conn, $id);
    $product_code = mysqli_real_escape_string($conn, $data->ProductCode);
    $product_name = mysqli_real_escape_string($conn, $data->ProductName);
    $price = floatval($data->Price);
    $price_promotion = floatval($data->PricePromotion);
    $tax = floatval($data->Tax);
    $promotion = intval($data->Promotion);
    $is_active = intval($data->IsActive);
    $created = date("Y-m-d");

    $query = "UPDATE product SET ProductCode='$product_code', ProductName='$product_name', Price='$price', 
              PricePromotion='$price_promotion', Tax='$tax', Promotion='$promotion', IsActive='$is_active', 
              CreatedAt='$created' WHERE ID='$id'";

    $result = mysqli_query($conn, $query);

    if ($result) {
        $output = [
            "status" => 200,
            "data" => "Data Updated Successfully",
            "error" => false
        ];
    } else {
        $output = [
            "status" => 500,
            "data" => "Failed to update data",
            "error" => true
        ];
    }

    echo json_encode($output);
}

// Função para excluir um registro
function deleteProduct($id) {
    global $conn;

    $id = mysqli_real_escape_string($conn, $id);

    $query = "SELECT * FROM product WHERE ID='$id' AND IsActive='Active'";
    $result = mysqli_query($conn, $query);
    $numRows = mysqli_num_rows($result);

    if ($numRows > 0) {
        $query = "DELETE FROM product WHERE ID='$id'";
        $result = mysqli_query($conn, $query);

        $output = [
            "status" => 200,
            "data" => "Data Deleted Successfully",
            "error" => false
        ];
    } else {
        $output = [
            "status" => 404,
            "data" => "No Record Found",
            "error" => true
        ];
    }

    echo json_encode($output);
}

// Verifica o método da requisição
$method = $_SERVER['REQUEST_METHOD'];

// Executa a função apropriada com base no método da requisição
/*switch ($method) {
    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        createProduct($data);
        break;
    case 'GET':
        if (isset($_GET['ID']) && $_GET['ID'] != "") {
            $id = $_GET['ID'];
            getProduct($id);
        } else {
            getAllProducts();
        }
        break;
    case 'PUT':
        if (isset($_GET['ID']) && $_GET['ID'] != "") {
            $id = $_GET['ID'];
            $data = json_decode(file_get_contents("php://input"));
            updateProduct($id, $data);
        }
        break;
    case 'DELETE':
        if (isset($_GET['ID']) && $_GET['ID'] != "") {
            $id = $_GET['ID'];
            deleteProduct($id);
        }
        break;
    default:
        $output = [
            "status" => 400,
            "data" => "Invalid Request Method",
            "error" => true
        ];
        echo json_encode($output);
        break;
}
*/
if ($method == 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    $controller->createProduct($data);
    //createProduct($data);
}elseif ($method == 'GET') {
    if (isset($_GET['ID']) && $_GET['ID'] != "") {
        $id = $_GET['ID'];
        $controller->getProduct($id);
    } else {
        $controller->getAllProducts();
    }
}elseif ($method == 'PUT') {
    if (isset($_GET['ID']) && $_GET['ID'] != "") {
        $id = $_GET['ID'];
        $data = json_decode(file_get_contents("php://input"));
        $controller->updateProduct($id, $data);
    }
}elseif ($method == 'DELETE') {
    if (isset($_GET['ID']) && $_GET['ID'] != "") {
        $id = $_GET['ID'];
        $controller->deleteProduct($id);
    }
}else{
    $output = [
        "status" => 400,
        "data" => "Invalid Request Method",
        "error" => true
    ];
    echo json_encode($output);
}

?>
