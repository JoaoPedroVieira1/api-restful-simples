<?php

require 'connection.php'; // chama o arquivo de conexão com banco de dados

if(isset($_GET['ID']) && $_GET['ID'] != ""){ // verifica se ID foi enviado pela URL e se não esta vazio
    $id = mysqli_real_escape_string($conn, $_GET['ID']); 

    $query = "SELECT * FROM product WHERE ID='$id'"; // busca um registro na tabela com base no ID

    $result = mysqli_query($conn, $query); // executa consulta no banco de dados
    $numRows = mysqli_num_rows($result); // número de linhas da consulta

    // verifica se a consulta retornou resultado
    if($numRows>0){
        $output = mysqli_fetch_assoc($result);
        $output = [
            "status" => 200,
            "data" => $output,
            "error" => false
        ];
    }else{
        $output = "No Record Found";
        $output = [
            "status" => 404,
            "data" => $output,
            "error" => true
        ];
    }
}else{
    // busca todos os registros da tabela
    $query = "SELECT * FROM product";

    $result = mysqli_query($conn, $query); // executa a consulta no banco de dados
    $output = array(); // armazena os resultados

    while($row = mysqli_fetch_assoc($result)){ // percorre os resultados adicionando no array
        array_push($output, $row);
    }
    $output = [
        "status" => 200,
        "data" => $output,
        "error" => false
    ];
}

echo json_encode($output); // converte a saída para JSON e exibe na tela