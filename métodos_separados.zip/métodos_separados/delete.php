<?php

if(isset($_GET['ID']) && $_GET['ID'] != ""){ // verifica se ID esta definido e não esta vazio
    $id = mysqli_real_escape_string($conn, $_GET['ID']); // escapa o valor de ID
    $query = "SELECT * FROM product WHERE ID='$id' AND IsActive='Active'"; // seleciona registros com o ID fornecido e onde IsActive esta ativo

    $result = mysqli_query($conn, $query); // consulta no banco de dados
    $numRows = mysqli_num_rows($result); // obtém o número de linhas

    if($numRows>0){
        $query = "DELETE FROM product WHERE ID='$id'"; // exclui o registro com ID fornecido
        $exe = mysqli_query($conn, $query); // executa a exclusão
        $output = [
            "status" => 200,
            "data" => "Data Deleted Successfully",
            "error" => false
        ];
    }else{
        $output = [
            "status" => 404,
            "data" => "No Record Found",
            "error" => false
        ];
    }
}else{
    $output = [
        "status" => 404,
        "data" => "No Query Param Found",
        "error" => false
    ];
}

echo json_encode($output); // converte o array em JSON e imprime na saída