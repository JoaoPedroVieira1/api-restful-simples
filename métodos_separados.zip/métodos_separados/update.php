<?php

// verifica se ID e IsActive estão definidos na requisição GET
if(isset($_GET[`ID`]) && $_GET[`IsActive`]){
    // recupera e escapa os valores de ID e IsActive
    $id = mysqli_real_escape_string($conn, $_GET['ID']);
    $status = mysqli_real_escape_string($conn, $_GET['IsActive']);

    // consulta SQL para selecionar linhas da tabela com vase nos valores ID e IsActive
    $query = "SELECT * FROM product WHERE ID='$id' AND IsActive='Active'";

    $result = mysqli_query($conn, $query); // executa consulta
    $numRows = mysqli_num_rows($result); // obtém o número de linhas

    if($numRows>0){
        if($status == 'Active'){
            $action = "Inactive"; 
        }else{
            $action = "Active";
        }

        // consulta SQL para atualizar valor IsActive do produto
        $updateQuery = "UPDATE product SET `IsActive`='$action' WHERE `ID`='$id'";
        $exe = mysqli_query($conn, $updateQuery); // executa consulta de atualização

        $output = [
            "status" => 200,
            "data" => "Data Updated Successfully",
            "error" => false
        ];
    }
}else{
    $output = [
        "status" => 404,
        "data" => "No Query Param Found",
        "error" => false
    ];
}

echo json_encode($output); // converte array de saída para JSON e imprime