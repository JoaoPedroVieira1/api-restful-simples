<?php

    require 'connection.php'; // chama o arquivo de conexão com banco de dados

    if ($_SERVER['REQUEST_METHOD'] == "POST") { // verifica se o método da requisição é POST

        $data = json_decode(file_get_contents("php://input")); // obtém os dados enviados na requisição

        // obtém os valores dos campos enviados
        $product_code = mysqli_real_escape_string($conn, $data->ProductCode);
        $product_name = mysqli_real_escape_string($conn, $data->ProductName);
        $price = floatval($data->Price);
        $price_promotion = floatval($data->PricePromotion);
        $tax = floatval($data->Tax);
        $promotion = intval($data->Promotion);
        $is_active = intval($data->IsActive);
        $created = date("Y-m-d");

        if(isset($_GET[`ID`]) && $_GET[`ID`] != ""){ // verifica se existe parâmetro ID na URL e se não esta vazio
            $id = mysqli_real_escape_string($conn, $_GET[`ID`]); // obtém o valor de ID
            // verifica se o registro com o ID existe no banco de dados
            $query = mysqli_query($conn, "SELECT * FROM product WHERE `ID`='$id'"); 
            $num_rows = mysqli_num_rows($query); // obtém o número de linhas
            if($num_rows>0){ // se houver registros
                //atualiza os valores do registro
                $updateQuery = "UPDATE product SET `ProductCode`='$product_code', `ProductName`='$product_name', `Price`='$price', `PricePromotion`='$price_promotion', `Tax`='$tax', `Promotion`='$promotion', `IsActive`='$is_active', `CreatedAt`='$created' WHERE `ID`='$id'";
                $exe = mysqli_query($conn, $updateQuery); // executa a atualização no banco de dados
                $output = [
                    "status" => 200,
                    "data" => "Data Updated Successfully",
                    "error" => false
                ];
            }else{
                $output = [
                    "status" => 404,
                    "data" => "No Record Found",
                    "error" => true
                ];
            }

        }else{ // se ID não estiver na URL
            // insere um novo registro com os valores fornecidos
            $query = "INSERT INTO product(ProductCode, ProductName, Price, PricePromotion, Tax, Promotion, IsActive, CreatedAt) VALUES ('$product_code', '$product_name', '$price', '$price_promotion', '$tax', '$promotion', '$is_active', '$created')";
        
            $exe = mysqli_query($conn, $query); // executa a inserção no banco de dados

            $output = [
                "status" => 200,
                "data" => "Data insert successfully",
                "error" => false
            ];
        }
        
    }else{
        $output = [
            "status" => 404,
            "data" => "No POST REQUEST METHOD FOUND",
            "error" => false
        ];
    }

    echo json_encode($output); // imprime o resultado final como uma resposta JSON
?>